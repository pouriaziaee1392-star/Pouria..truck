// Simple top-down prototype for Pouria Truck
(function(){
  const c=document.getElementById('game'),ctx=c.getContext('2d');
  const truck={x:400,y:480,w:80,h:140,s:0};
  document.getElementById('start').onclick=function(){loop()};
  window.addEventListener('keydown',e=>{if(e.key==='ArrowLeft')truck.x-=10;if(e.key==='ArrowRight')truck.x+=10;if(e.key==='ArrowUp')truck.s+=1;if(e.key==='ArrowDown')truck.s-=1});
  function draw(){ctx.clearRect(0,0,800,600);ctx.fillStyle='#444';ctx.fillRect(160,0,480,600);ctx.fillStyle='#ff7b00';ctx.fillRect(truck.x-truck.w/2,truck.y-truck.h/2,truck.w,truck.h);}
  function loop(){truck.x+=truck.s;draw();requestAnimationFrame(loop);}
})();
