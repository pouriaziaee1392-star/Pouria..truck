Pouria Truck - Complete Android Studio project (prototype)
=========================================================

What you get:
- Ready Android Studio project wrapping an HTML5 prototype in a WebView.
- MainActivity loads splash then index.html from assets.
- Placeholder gradlew and gradle-wrapper are included — Android Studio will generate proper wrapper if needed.

How to build (recommended, on PC with Android Studio):
1. Download and extract this ZIP.
2. Open Android Studio -> File -> Open -> select this project folder.
3. If Android Studio prompts to install SDK components, accept.
4. If gradle wrapper is missing or placeholder, in Android Studio Terminal run:
   gradle wrapper
   (or use Android Studio menu to generate Gradle wrapper)
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s)
6. APK will appear under app/build/outputs/apk/debug/

If you want, I can:
- Add a real Gradle wrapper files (gradle-wrapper.jar from a valid distribution) so GitHub Actions can build directly.
- Create a Release-signed workflow that uses GitHub Secrets for keystore.
- Convert this project into a Unity project for better performance and native features.
