@echo off
echo This is a placeholder gradlew. Generate a real Gradle wrapper with 'gradle wrapper' or open in Android Studio.
exit /b 1
